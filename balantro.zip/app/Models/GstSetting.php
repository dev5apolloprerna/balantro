<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GstSetting extends Model
{
    use HasFactory;
    protected $fillable = [
        'iPartyId',
        'IsItemWiseGST',
        'IsItemWise',
        'IsActive'
    ];
}
