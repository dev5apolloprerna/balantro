<div id="assignGroupsModal" class="hidden fixed inset-0 z-50">
    <div class="absolute inset-0 bg-black/60"></div>
    <div class="relative mx-auto mt-20 w-[720px] max-w-[95%] rounded-2xl bg-neutral-900 text-white shadow-xl">
        <div class="flex items-center justify-between px-6 py-4 border-b border-neutral-700">
            <h2 class="text-xl font-semibold">Assign Groups</h2>
            <button type="button" onclick="closeGroupsModal()" class="text-neutral-400 hover:text-white">✕</button>
        </div>
        <form id="assignGroupsForm" method="POST" class="px-6 py-5">
            @csrf
            <div id="groupsList" class="max-h-[60vh] overflow-y-auto space-y-2 pr-1">
                <!-- filled by JS -->
            </div>
            <div class="flex justify-end gap-3 pt-5 pb-6">
                <button type="button" onclick="closeGroupsModal()"
                    class="rounded-md border border-neutral-600 px-4 py-2 text-sm text-neutral-200 hover:bg-neutral-800">Cancel</button>
                <button type="submit"
                    class="rounded-md bg-primary-600 px-4 py-2 text-sm font-medium text-white hover:bg-primary-700">Save</button>
            </div>
        </form>
    </div>
</div>
