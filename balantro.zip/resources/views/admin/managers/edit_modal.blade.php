<!-- <div id="editModal" class="hidden fixed inset-0 z-50 items-center justify-center bg-slate-950/60 p-4 backdrop-blur-sm">
    <div class="absolute inset-0" onclick="closeEditModal()"></div>
    <div class="balantro-modal-panel relative w-full max-w-2xl rounded-2xl bg-white text-slate-900 shadow-xl dark:bg-slate-900 dark:text-white">
        <div class="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-700">
            <h2 class="text-xl font-semibold">Edit</h2> <button type="button" onclick="closeEditModal()"
                class="rounded-full p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-white">✕</button>
        </div>
        <form id="editForm" method="POST" class="px-6 py-5 space-y-5"> @csrf @method('PUT')

            <input type="hidden" name="fcm_token" id="e_fcm_token">
            <input type="hidden" name="device_type" id="e_device_type">
            <input type="hidden" name="browser_name" id="e_browser_name">
            <input type="hidden" name="os_name" id="e_os_name">
            <div> <label class="block text-sm font-medium mb-1">Name <span class="text-red-500">*</span></label> <input
                    id="edit_name" name="name" type="text"
                    class="w-full rounded-md border border-slate-300 bg-white dark:border-slate-700 dark:bg-slate-800 dark:text-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500">
            </div>
            <div> <label class="block text-sm font-medium mb-1">Email <span class="text-red-500">*</span></label> <input
                    id="edit_email" name="email" type="email"
                    class="w-full rounded-md border border-slate-300 bg-white dark:border-slate-700 dark:bg-slate-800 dark:text-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-500">
            </div>
            <div class="flex justify-end gap-3 pt-2 pb-5"> <button type="button" onclick="closeEditModal()"
                    class="rounded-md border border-slate-300 px-4 py-2 text-sm text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800">Cancel</button>
                <button type="submit"
                    class="rounded-md bg-primary-600 px-4 py-2 text-sm font-medium text-white hover:bg-primary-700">Save</button>
            </div>
        </form>
    </div>
</div>1 -->

@include('admin.shared.user_form_modal', [
    'modalId' => 'editModal',
    'formId' => 'editForm',
    'title' => 'Edit Manager',
    'closeAction' => 'closeEditModal()',
    'nameId' => 'edit_name',
    'emailId' => 'edit_email',
    'mode' => 'edit',
    'method' => 'PUT',
])

<script>
    // async function fillEditDeviceInfo() {
    //     // Device type
    //     let deviceType = /Mobi|Android/i.test(navigator.userAgent) ?
    //         "mobile" :
    //         "pc";

    //     // Browser name (basic detection)
    //     let browserName = "Unknown";
    //     if (/Chrome/i.test(navigator.userAgent)) browserName = "Chrome";
    //     else if (/Firefox/i.test(navigator.userAgent)) browserName = "Firefox";
    //     else if (
    //         /Safari/i.test(navigator.userAgent) &&
    //         !/Chrome/i.test(navigator.userAgent)
    //     )
    //         browserName = "Safari";
    //     else if (/Edge/i.test(navigator.userAgent)) browserName = "Edge";

    //     // OS name
    //     let osName = "Unknown";
    //     if (/Win/i.test(navigator.userAgent)) osName = "Windows";
    //     else if (/Mac/i.test(navigator.userAgent)) osName = "MacOS";
    //     else if (/Linux/i.test(navigator.userAgent)) osName = "Linux";
    //     else if (/Android/i.test(navigator.userAgent)) osName = "Android";
    //     else if (/iPhone|iPad|iPod/i.test(navigator.userAgent)) osName = "iOS";

    //     document.getElementById("e_device_type").value = deviceType;
    //     document.getElementById("e_browser_name").value = browserName;
    //     document.getElementById("e_os_name").value = osName;

    //     // Try to fetch FCM token
    //     // try {
    //     const perm = await Notification.requestPermission();

    //     if (perm === "granted") {
    //         const token = await messaging.getToken({
    //             vapidKey: VAPID_PUBLIC_KEY,
    //         });
    //         if (token) {
    //             document.getElementById("e_fcm_token").value = token;
    //         }
    //     }
    //     // } catch (e) {
    //     //     console.warn("FCM token skipped:", e);
    //     // }
    // }

    document.getElementById("editForm").addEventListener("submit", async function(e) {
        e.preventDefault();

        // await fillEditDeviceInfo();

        // Wait for next event loop cycle
        await new Promise(resolve => setTimeout(resolve, 50));

        console.log("Submitting with:", {
            fcm: document.getElementById("e_fcm_token").value,
            device: document.getElementById("e_device_type").value,
            browser: document.getElementById("e_browser_name").value,
            os: document.getElementById("e_os_name").value,
        });

        this.submit();
    });
</script>
